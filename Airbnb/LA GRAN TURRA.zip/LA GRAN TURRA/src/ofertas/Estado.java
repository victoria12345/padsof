package ofertas;
/**
 * Los posibles estados de una oferta
 * @author Victoria
 *
 */
public enum Estado {
	ACEPTADA, RECHAZADA ,RECTIFICADA, PENDIENTE
}