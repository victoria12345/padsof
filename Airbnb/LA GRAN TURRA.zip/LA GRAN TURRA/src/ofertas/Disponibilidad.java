package ofertas;
/**
 * Los posibles estados de disponibilidad de una oferta
 * @author Victoria PElayo e Ignacio Rabunnal
 *
 */
public enum Disponibilidad{
	DISPONIBLE, RESERVADA, CONTRATADA
}